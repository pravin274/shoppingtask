export const inventory = [
    {
        "name": "orange",
        "price": 36,
        "category": ["Dairy"]
    },
    {
        "name": "lemon",
        "price": 25,
        "category": ["Snack"]
    },
    {
        "name": "grape",
        "price": 10,
        "category": ["Dairy"]
    },
    {
        "name": "kiwi",
        "price": 45,
        "category": ["Dairy"]
    },
    {
        "name": "Apple",
        "price": 20,
        "category": ["Fruit"]
    },
    {
        "name": "watermelon",
        "price": 25,
        "category": ["Dairy","Snack"]
    }
];

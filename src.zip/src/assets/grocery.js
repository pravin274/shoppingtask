export const inventory = [
    {
        "name": "orange",
        "price": 36,
        "category": ["fruit"]
    },
    {
        "name": "lemon",
        "price": 25,
        "category": ["fruit"]
    },
    {
        "name": "grape",
        "price": 10,
        "category": ["fruit"]
    },
    {
        "name": "kiwi",
        "price": 45,
        "category": ["fruit"]
    },
    {
        "name": "Apple",
        "price": 20,
        "category": ["Fruit"]
    },
    {
        "name": "watermelon",
        "price": 25,
        "category": ["fruit","fruit"]
    }
];

export class InventoryModel {
  name: string;
  price: number;
  category: string [];
}
